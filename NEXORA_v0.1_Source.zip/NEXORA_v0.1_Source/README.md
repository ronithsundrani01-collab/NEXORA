NEXORA v0.1 Genesis
