rootProject.name="NEXORA"
include(":app")
